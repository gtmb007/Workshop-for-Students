package com.example.gautam.workshop.activity

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.example.gautam.workshop.R

class AboutUs : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about_us)
    }
}
