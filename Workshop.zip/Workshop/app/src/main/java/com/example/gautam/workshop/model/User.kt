package com.example.gautam.workshop.model

class User(){
    var id: Int? = -1
    var name: String? = null
    var email: String? = null
    var password: String? = null
}
