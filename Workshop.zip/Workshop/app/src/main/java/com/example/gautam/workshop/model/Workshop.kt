package com.example.gautam.workshop.model

class Workshop(){
    var workshopId: Int? = -1
    var workshopName: String? = null
    var organisationName: String? = null
}